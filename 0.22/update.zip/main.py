#!/usr/bin/env python3
import sys
import os
import warnings
warnings.filterwarnings("ignore", message="xFormers is not available")


current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)
# ИСПРАВЛЕНИЕ для pythonw.exe - создаем фиктивные stdout/stderr
class DummyStream:
    def write(self, text):
        pass
    def flush(self):
        pass
if sys.stderr is None:
    sys.stderr = DummyStream()
if sys.stdout is None:
    sys.stdout = DummyStream()
# ОСТАЛЬНЫЕ импорты (убрать дублирующиеся import sys/os)
import json
import hashlib
import platform
import subprocess
from pathlib import Path
from datetime import datetime, timedelta
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtQml import QQmlApplicationEngine, qmlRegisterType
from PyQt5.QtCore import QUrl, QObject, pyqtSignal, pyqtSlot, QTimer
from PyQt5.QtWidgets import QFileDialog, QApplication
# Отключаем все print
import builtins
builtins.print = lambda *args, **kwargs: None
##############################################################
# Флаг для Windows (убирает всплывающее окно при subprocess.run)
CREATE_NO_WINDOW = 0x08000000
def run_silent(args, **kw):
    """subprocess.run без всплывающего окна на Windows"""
    if sys.platform.startswith("win"):
        kw.setdefault("creationflags", CREATE_NO_WINDOW)
    return subprocess.run(args, **kw)
####################################################################
# НЕ ОТКЛЮЧАЙТЕ print - это нужно для отладки!
# Только отключите QML логи
os.environ["QT_LOGGING_RULES"] = "*=false"
try:
    from cryptography.fernet import Fernet
    import base64
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    print("Warning: Cryptography not available - license features disabled")
def get_hardware_id():
    """Генерирует стабильный идентификатор системы (адаптировано из старой логики)"""
    try:
        stable_components = []
        
        # 1. Серийный номер материнской платы (САМЫЙ СТАБИЛЬНЫЙ)
        motherboard_serial = None
        try:
            if platform.system() == "Windows":
                result = run_silent(
                    ['wmic', 'baseboard', 'get', 'serialnumber'],
                    capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore'
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        line = line.strip()
                        if line and line != 'SerialNumber' and line not in ['To be filled by O.E.M.', 'Default string']:
                            motherboard_serial = line
                            break
            
            elif platform.system() == "Linux":
                try:
                    with open('/sys/class/dmi/id/board_serial', 'r') as f:
                        serial = f.read().strip()
                        if serial and serial not in ['Not Specified', 'Default string', 'To be filled by O.E.M.']:
                            motherboard_serial = serial
                except:
                    try:
                        with open('/sys/class/dmi/id/product_uuid', 'r') as f:
                            uuid_sys = f.read().strip()
                            if uuid_sys:
                                motherboard_serial = uuid_sys
                    except:
                        pass
                    
            elif platform.system() == "Darwin":  # macOS
                result = run_silent(
                    ['wmic', 'baseboard', 'get', 'serialnumber'],
                    capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore'
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if 'Serial Number' in line:
                            serial = line.split(':')[-1].strip()
                            if serial:
                                motherboard_serial = serial
                            break
        except:
            pass
        
        if motherboard_serial:
            stable_components.append(f"MB:{motherboard_serial}")
        
        # 2. Модель процессора (НИКОГДА НЕ ИЗМЕНЯЕТСЯ)
        cpu_model = None
        try:
            if platform.system() == "Windows":
                result = run_silent(
                    ['wmic', 'cpu', 'get', 'name'],
                    capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore'
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        line = line.strip()
                        if line and line != 'Name':
                            cpu_model = line
                            break
            
            elif platform.system() == "Linux":
                try:
                    with open('/proc/cpuinfo', 'r') as f:
                        for line in f:
                            if line.startswith('model name'):
                                cpu_model = line.split(':')[1].strip()
                                break
                except:
                    pass
            
            elif platform.system() == "Darwin":  # macOS
                result = subprocess.run([
                    'sysctl', '-n', 'machdep.cpu.brand_string'
                ], capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore')
                if result.returncode == 0:
                    cpu_model = result.stdout.strip()
        except:
            pass
        
        if cpu_model:
            stable_components.append(f"CPU:{cpu_model}")
        
        # 3. Серийный номер системного диска
        system_disk_serial = None
        try:
            if platform.system() == "Windows":
                result = run_silent(
                    ['wmic', 'logicaldisk', 'where', 'caption="C:"', 'get', 'volumeserialnumber'],
                    capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore'
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        line = line.strip()
                        if line and line != 'VolumeSerialNumber':
                            system_disk_serial = line
                            break
            
            elif platform.system() == "Linux":
                try:
                    result = subprocess.run([
                        'findmnt', '-n', '-o', 'UUID', '/'
                    ], capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore')
                    if result.returncode == 0:
                        uuid = result.stdout.strip()
                        if uuid:
                            system_disk_serial = uuid
                except:
                    pass
            
            elif platform.system() == "Darwin":  # macOS
                result = subprocess.run([
                    'diskutil', 'info', '/'
                ], capture_output=True, text=True, timeout=5, encoding='utf-8', errors='ignore')
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if 'Volume UUID' in line:
                            uuid = line.split(':')[-1].strip()
                            if uuid:
                                system_disk_serial = uuid
                            break
        except:
            pass
        
        if system_disk_serial:
            stable_components.append(f"DISK:{system_disk_serial}")
        
        # 4. Fallback если основные параметры недоступны
        if len(stable_components) == 0:
            stable_components.extend([
                f"SYS:{platform.system()}",
                f"ARCH:{platform.machine()}",
                f"PROC:{platform.processor()}"
            ])
        
        # Создаем стабильный отпечаток из найденных компонентов
        combined = "|".join(stable_components)
        fingerprint = hashlib.sha256(combined.encode('utf-8')).hexdigest()
        
        return fingerprint[:16].upper()
        
    except Exception as e:
        print(f"Error generating hardware ID: {e}")
        return "FALLBACK_ID"
def validate_startup_license():
    """Проверяет лицензию при запуске"""
    license_file = Path("license.dat")
    
    if not license_file.exists():
        return {
            "valid": False,
            "error": "License file not found",
            "hardware_id": get_hardware_id()
        }
    
    if not CRYPTO_AVAILABLE:
        return {
            "valid": False,
            "error": "Cryptography library not available",
            "hardware_id": get_hardware_id()
        }
    
    try:
        with open(license_file, 'rb') as f:
            encrypted_data = f.read()
        
        key = base64.urlsafe_b64encode(hashlib.sha256(b"RoLo_License_Key_2025").digest())
        fernet = Fernet(key)
        
        decrypted_data = fernet.decrypt(encrypted_data)
        license_info = json.loads(decrypted_data.decode())
        
        license_type = license_info.get("type", "")
        current_hwid = get_hardware_id()
        
        if license_type in ["full", "full_time"]:
            if license_info.get("hardware_id") != current_hwid:
                return {
                    "valid": False,
                    "error": "Hardware ID mismatch",
                    "hardware_id": current_hwid
                }
        
        if license_type in ["full_time", "test"]:
            expiry_str = license_info.get("expiry_date")
            if expiry_str:
                expiry_date = datetime.fromisoformat(expiry_str)
                if datetime.now() > expiry_date:
                    return {
                        "valid": False,
                        "error": "License expired",
                        "hardware_id": current_hwid
                    }
        
        return {
            "valid": True,
            "type": license_type,
            "expires": license_info.get("expiry_date"),
            "user": license_info.get("user_name", "Licensed User")
        }
        
    except Exception as e:
        return {
            "valid": False,
            "error": f"License validation failed: {str(e)}",
            "hardware_id": get_hardware_id()
        }
def create_license_file(user_name, license_type, duration_days=None, hardware_id=None):
    """Создает файл лицензии"""
    if not CRYPTO_AVAILABLE:
        return False, "Cryptography not available"
    
    try:
        license_data = {
            "user_name": user_name,
            "type": license_type,
            "created": datetime.now().isoformat(),
            "version": "1.0"
        }
        
        if license_type in ["full", "full_time"]:
            license_data["hardware_id"] = hardware_id or get_hardware_id()
        
        if license_type in ["full_time", "test"] and duration_days:
            expiry_date = datetime.now() + timedelta(days=duration_days)
            license_data["expiry_date"] = expiry_date.isoformat()
        
        key = base64.urlsafe_b64encode(hashlib.sha256(b"RoLo_License_Key_2025").digest())
        fernet = Fernet(key)
        
        json_data = json.dumps(license_data, indent=2)
        encrypted_data = fernet.encrypt(json_data.encode())
        
        # КРИТИЧНО для exe: принудительная запись на диск
        with open("license.dat", 'wb') as f:
            f.write(encrypted_data)
            f.flush()  # Сбрасываем буфер Python
            os.fsync(f.fileno())  # Синхронизируем с диском Windows
        
        return True, f"License created: {license_type}"
        
    except Exception as e:
        return False, f"Failed to create license: {str(e)}"
    
def show_license_dialog(self, hardware_id, error_message):
    """Показывает графический диалог лицензирования"""
    try:
        self.dialog_engine = QQmlApplicationEngine()
        self.dialog_engine.rootContext().setContextProperty("licenseManager", self)
        
        qml_file = Path("qml/LicenseDialog.qml")
        if not qml_file.exists():
            print(f"License dialog QML not found: {qml_file}")
            return False
        
        def on_dialog_created(obj, url):
            if obj is None:
                print("Failed to load license dialog")
                return
            
            self.dialog_window = obj
            obj.setProperty("hardwareId", hardware_id)
            obj.setProperty("errorMessage", error_message)
            obj.show()
        
        self.dialog_engine.objectCreated.connect(on_dialog_created)
        self.dialog_engine.load(QUrl.fromLocalFile(str(qml_file.absolute())))
        
        return True
        
    except Exception as e:
        print(f"Error showing license dialog: {e}")
        return False
def get_license_status():
    """Возвращает текущий статус лицензии"""
    result = validate_startup_license()
    return result
class LicenseDialogManager(QObject):
    """Менеджер для диалога лицензирования"""
    
    activationRequested = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.dialog_window = None
        self.dialog_engine = None
    
    def show_license_dialog(self, hardware_id, error_message):
        """Показывает графический диалог лицензирования"""
        try:
            self.dialog_engine = QQmlApplicationEngine()
            self.dialog_engine.rootContext().setContextProperty("licenseManager", self)
            
            qml_file = Path("qml/LicenseDialog.qml")
            if not qml_file.exists():
                print(f"License dialog QML not found: {qml_file}")
                return False
            
            def on_dialog_created(obj, url):
                if obj is None:
                    print("Failed to load license dialog")
                    return
                
                self.dialog_window = obj
                obj.setProperty("hardwareId", hardware_id)
                obj.setProperty("errorMessage", error_message)
                obj.setProperty("onActivate", self.on_activate_clicked)
                obj.setProperty("copyToClipboard", self.copy_to_clipboard)
                obj.show()
            
            self.dialog_engine.objectCreated.connect(on_dialog_created)
            self.dialog_engine.load(QUrl.fromLocalFile(str(qml_file.absolute())))
            
            return True
            
        except Exception as e:
            print(f"Error showing license dialog: {e}")
            return False
    
    @pyqtSlot(str)
    def on_activate_clicked(self, license_code):
        """Обработчик нажатия кнопки Activate"""
        self.activationRequested.emit(license_code)
    
    @pyqtSlot(str)
    def copy_to_clipboard(self, text):
        """Копирует текст в буфер обмена"""
        try:
            from PyQt5.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText(text)
            print(f"Copied to clipboard: {text}")
            return True
        except Exception as e:
            print(f"Failed to copy to clipboard: {e}")
            return False
    
    def set_validation_error(self, error_message):
        """Устанавливает ошибку валидации"""
        if self.dialog_window:
            self.dialog_window.setProperty("validationError", error_message)
    
    def close_dialog(self):
        """Закрывает диалог безопасно"""
        if self.dialog_window:
            # Используем deleteLater для безопасного закрытия
            from PyQt5.QtCore import QTimer
            QTimer.singleShot(100, self.dialog_window.close)
            QTimer.singleShot(200, lambda: setattr(self, 'dialog_window', None))
        if self.dialog_engine:
            QTimer.singleShot(300, lambda: setattr(self, 'dialog_engine', None))
class SearchManager(QObject):
    """Управление поиском - Python backend"""
    
    searchResults = pyqtSignal(list)
    
    def __init__(self):
        super().__init__()
        self._max_results = 20
        self._similarity_threshold = 0.75
        
    @pyqtSlot(str)
    def performImageSearch(self, image_path):
        """Выполняет поиск по изображению"""
        print(f"🔍 Image search for: {image_path}")
        # Здесь будет интеграция с ML моделями
        mock_results = [
            {"name": "Plant 1", "similarity": 0.95, "path": "/path/1.jpg"},
            {"name": "Plant 2", "similarity": 0.87, "path": "/path/2.jpg"}
        ]
        self.searchResults.emit(mock_results)
    
    @pyqtSlot(str)
    def performTextSearch(self, query):
        """Выполняет текстовый поиск"""
        print(f"📝 Text search for: {query}")
        # Здесь будет поиск по тексту
        
    @pyqtSlot(int)
    def setMaxResults(self, max_results):
        """Устанавливает максимальное количество результатов"""
        self._max_results = max_results
        print(f"📊 Max results set to: {max_results}")
class ImageSearchManager(QObject):
    """Менеджер для Image Search виджета"""
    
    # Сигналы для QML
    imageFileSelected = pyqtSignal(str)  # путь к выбранному файлу
    
    def __init__(self):
        super().__init__()
    
    @pyqtSlot()
    def select_image_file(self):
        """Открывает диалог выбора изображения"""
        try:
            # Получаем экземпляр приложения
            app = QApplication.instance()
            if not app:
                print("❌ No QApplication instance found")
                return
            
            # Диалог выбора файла
            file_path, _ = QFileDialog.getOpenFileName(
                None,
                "Select Image File",
                "",
                "Images (*.png *.jpg *.jpeg *.bmp *.gif *.tiff);;All Files (*)"
            )
            
            if file_path:
                print(f"📁 Selected image file: {file_path}")
                self.imageFileSelected.emit(file_path)
            else:
                print("📁 No file selected")
                
        except Exception as e:
            print(f"❌ Error selecting image file: {e}")
    @pyqtSlot(str)
    def open_image_in_viewer(self, image_path):
        """Открывает изображение в системном просмотрщике"""
        try:
            if not os.path.exists(image_path):
                print(f"❌ Image file not found: {image_path}")
                return
            
            import platform
            system = platform.system()
            
            if system == "Windows":
                os.startfile(image_path)
            elif system == "Darwin":  # macOS
                subprocess.run(["open", image_path])
            else:  # Linux
                subprocess.run(["xdg-open", image_path])
                
            print(f"🖼️ Opened image in viewer: {image_path}")
            
        except Exception as e:
            print(f"❌ Error opening image: {e}")
def activate_license_from_code(license_code, activation_code):
    """Активирует лицензию по сложному коду"""
    try:
        if len(license_code) < 20:
            return False, "Invalid license code format"
        
        parts = license_code.split('-')
        if len(parts) != 3:
            return False, "Invalid license code structure"
        
        # Проверяем маркеры типов
        middle_part = parts[1]
        
        if middle_part.startswith("F7A"):
            license_type = "full"
            duration_days = None
        elif middle_part.startswith("T6B"):
            license_type = "full_time"
            # Извлекаем дни из hex
            try:
                days_hex = middle_part[3:5]
                duration_days = int(days_hex, 16)
            except:
                duration_days = 30
        elif middle_part.startswith("E9C"):
            license_type = "test"
            try:
                days_hex = middle_part[3:5]
                duration_days = int(days_hex, 16)
            except:
                duration_days = 7
        else:
            return False, "Unknown license type"
        
        success, message = create_license_file(
            user_name="Licensed User",
            license_type=license_type,
            duration_days=duration_days,
            hardware_id=activation_code
        )
        
        return success, message
        
    except Exception as e:
        return False, f"Activation failed: {str(e)}"
def show_license_dialog_gui(hardware_id, error_message, app):
    """Показывает графический диалог лицензирования"""
    print(f"Opening license dialog with hardware_id: {hardware_id}")
    
    dialog_manager = LicenseDialogManager()
    license_validated = False
    should_exit = False
    
    def on_activate(license_code):
        nonlocal license_validated
        print(f"Activating with code: {license_code} for hardware: {hardware_id}")
        success, message = activate_license_from_code(license_code, hardware_id)
        
        if success:
            # КРИТИЧНО для exe: даём время на запись файла
            import time
            time.sleep(0.3)  # 300ms задержка для Windows file buffering
            
            result = validate_startup_license()
            if result["valid"]:
                license_validated = True
                print("License activated successfully!")
                # Закрываем диалог с задержкой
                from PyQt5.QtCore import QTimer
                QTimer.singleShot(500, dialog_manager.close_dialog)
            else:
                dialog_manager.set_validation_error("License activation failed")
        else:
            dialog_manager.set_validation_error(message)
    
    dialog_manager.activationRequested.connect(on_activate)
    
    if not dialog_manager.show_license_dialog(hardware_id, error_message):
        return False
    
    # Упрощенный цикл ожидания
    timeout_counter = 0
    while not license_validated and timeout_counter < 3000:  # 5 минут максимум
        app.processEvents()
        if not dialog_manager.dialog_window:
            break
        import time
        time.sleep(0.1)
        timeout_counter += 1
    
    return license_validated
def main():
    """Запуск QML приложения с StartupLoader + License System"""
    
    app = QGuiApplication(sys.argv)
    
    print("Checking license...")
    license_result = validate_startup_license()
    if not license_result["valid"]:
        print(f"License validation failed: {license_result['error']}")
        if not show_license_dialog_gui(license_result["hardware_id"], license_result["error"], app):
            print("License validation cancelled by user")
            return 1
    else:
        print(f"License validated: {license_result['type']}")
        if license_result.get("expires"):
            expiry_date = datetime.fromisoformat(license_result['expires'])
            days_left = (expiry_date - datetime.now()).days
            print(f"License expires in {days_left} days: {license_result['expires']}")
        else:
            print("License: Permanent")
    
    qmlRegisterType(SearchManager, "RoLo", 1, 0, "SearchManager")
    try:
        from managers.startup_loader import get_startup_loader
        startup_loader = get_startup_loader()
        print("StartupLoader imported and created")
    except ImportError as e:
        print(f"Failed to import StartupLoader: {e}")
        startup_loader = None
    try:
        from managers.indexing_manager import get_indexing_manager
        indexing_manager = get_indexing_manager()
        print("Real IndexingManager imported and created")
        print("ML models will be loaded via StartupLoader")
    except ImportError as e:
        print(f"Failed to import Real IndexingManager: {e}")
        print("Make sure ml/ directory and models are available")
        try:
            from managers.simple_indexing_manager import get_simple_indexing_manager
            indexing_manager = get_simple_indexing_manager()
            print("Using Simple IndexingManager as fallback")
        except ImportError:
            print("No IndexingManager available!")
            return 1
    
    try:
        from managers.preset_manager import get_preset_manager
        preset_manager = get_preset_manager()
        print("PresetManager imported and created")
        
        if indexing_manager and hasattr(indexing_manager, 'indexing_completed'):
            indexing_manager.indexing_completed.connect(
                lambda message: preset_manager.refresh_default_preset()
            )
            print("Connected IndexingManager to PresetManager")
    except ImportError as e:
        print(f"Failed to import PresetManager: {e}")
        preset_manager = None
    
    try:
        from managers.ui_state_manager import get_ui_state_manager
        ui_state_manager = get_ui_state_manager()
        print("UIStateManager imported and created")
        
        ui_state_manager.load_state()
        print("UI state loaded on startup")
    except ImportError as e:
        print(f"Failed to import UIStateManager: {e}")
        ui_state_manager = None
    try:
        from managers.search_manager import get_search_manager
        search_manager = get_search_manager()
        print("SearchManager imported and created")
    except ImportError as e:
        print(f"Failed to import SearchManager: {e}")
        search_manager = None
    try:
        from managers.search_results_manager import get_search_results_manager
        search_results_manager = get_search_results_manager()
        print("SearchResultsManager imported and created")
    except ImportError as e:
        print(f"Failed to import SearchResultsManager: {e}")
        search_results_manager = None
    
    try:
        from managers.crop_manager import get_crop_manager
        crop_manager = get_crop_manager()
        print("CropManager imported and created")
    except ImportError as e:
        print(f"Failed to import CropManager: {e}")
        crop_manager = None
    
    try:
        from managers.drag_drop_manager import get_drag_drop_manager
        drag_drop_manager = get_drag_drop_manager()
        print("DragDropManager imported and created")
    except ImportError as e:
        print(f"Failed to import DragDropManager: {e}")
        drag_drop_manager = None
    image_search_manager = ImageSearchManager()
    print("ImageSearchManager created")
    engine = QQmlApplicationEngine()
    
    if startup_loader:
        engine.rootContext().setContextProperty("startupLoader", startup_loader)
        print("StartupLoader registered in QML context")
    if indexing_manager:
        engine.rootContext().setContextProperty("indexingManager", indexing_manager)
        print("IndexingManager registered in QML context")
    if preset_manager:
        engine.rootContext().setContextProperty("presetManager", preset_manager)
        print("PresetManager registered in QML context")
    if ui_state_manager:
        engine.rootContext().setContextProperty("uiStateManager", ui_state_manager)
        print("UIStateManager registered in QML context")
    if search_manager:
        engine.rootContext().setContextProperty("searchManager", search_manager)
        print("SearchManager registered in QML context")
    engine.rootContext().setContextProperty("imageSearchManager", image_search_manager)
    print("ImageSearchManager registered in QML context")
    if search_results_manager:
        engine.rootContext().setContextProperty("searchResultsManager", search_results_manager)
        
        if search_manager and hasattr(search_manager, 'search_completed'):
            search_manager.search_completed.connect(search_results_manager.show_search_results)
            print("Connected SearchManager to SearchResultsManager")
    if crop_manager:
        engine.rootContext().setContextProperty("cropManager", crop_manager)
        print("CropManager registered in QML context")
        
        crop_manager.cropCompleted.connect(
            lambda cropped_path: image_search_manager.imageFileSelected.emit(cropped_path)
        )
        print("Connected CropManager to ImageSearchManager")
    
    if drag_drop_manager:
        engine.rootContext().setContextProperty("dragDropManager", drag_drop_manager)
        print("DragDropManager registered in QML context")
        
        app.aboutToQuit.connect(drag_drop_manager.cleanup)
        print("Connected DragDropManager cleanup to app exit")
    if ui_state_manager:
        app.aboutToQuit.connect(ui_state_manager.save_on_exit)
        print("Connected UIStateManager to app exit")
    
    def setup_text_search_connections():
        try:
            main_object = engine.rootObjects()[0] if engine.rootObjects() else None
            if not main_object:
                print("Main QML object not found")
                return
                
            text_search_widget = main_object.findChild(QObject, "textSearchWidget")
            
            if text_search_widget and search_manager:
                if hasattr(search_manager, 'description_generated'):
                    search_manager.description_generated.connect(
                        lambda desc: text_search_widget.setProperty("descriptionText", desc)
                    )
                    print("Connected description generation to TextSearchWidget")
                    
                    search_manager.description_generated.connect(
                        lambda desc: text_search_widget.setDescription(desc) if hasattr(text_search_widget, 'setDescription') else None
                    )
        except Exception as e:
            print(f"Error connecting description signals: {e}")
    def register_text_search_widget():
        try:
            main_object = engine.rootObjects()[0] if engine.rootObjects() else None
            if not main_object:
                return
                
            text_search_widget = main_object.findChild(QObject, "textSearchWidget")
            drag_drop_manager_qml = main_object.findChild(QObject, "dragDropManager")
            
            if text_search_widget and drag_drop_manager_qml:
                try:
                    drag_drop_manager_qml.registerTextSearchWidget(text_search_widget)
                    print("TextSearchWidget registered in DragDropManager")
                except Exception as e:
                    print(f"Error calling registerTextSearchWidget: {e}")
        except Exception as e:
            print(f"Error registering TextSearchWidget: {e}")
    
    qml_dir = Path("qml")
    main_qml_path = qml_dir / "main.qml"
    
    if not main_qml_path.exists():
        print("QML файлы не найдены!")
        print("Убедитесь что папка qml/ содержит все необходимые файлы")
        return 1
    
    def on_object_created(obj, url):
        if obj is None:
            print("Ошибка загрузки QML!")
            print(f"Файл: {url}")
            app.quit()
        else:
            print("QML успешно загружен!")
            
            if startup_loader:
                print("Auto-starting model loading...")
                startup_loader.start_startup_loading()
            
            QTimer.singleShot(1000, setup_text_search_connections)
            QTimer.singleShot(1500, register_text_search_widget)
    
    engine.objectCreated.connect(on_object_created)
    engine.load(QUrl.fromLocalFile(str(main_qml_path.absolute())))
    
    print("RoLo Greenery запущен с лицензированием!")
    print("Модели начнут загружаться автоматически при старте")
    
    return app.exec_()
if __name__ == "__main__":
    sys.exit(main())