# splash_screen.py
import sys
import os
import time
import subprocess
from PyQt5.QtWidgets import QApplication, QSplashScreen
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPixmap, QPainter, QColor, QLinearGradient, QPen

class SplashScreen(QSplashScreen):
    def __init__(self):
        pixmap = QPixmap(450, 250)
        pixmap.fill(Qt.transparent)
        super().__init__(pixmap, Qt.WindowStaysOnTopHint)
        self.setFixedSize(450, 250)
        self.center_on_screen()
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Фон (цвета как в приложении - темная тема)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(35, 38, 43))      # #232B2B - темный
        gradient.setColorAt(1, QColor(42, 45, 49))      # #2A2D31 - чуть светлее
        painter.fillRect(self.rect(), gradient)
        
        # Рамка (акцентный цвет)
        pen = QPen(QColor(0, 192, 192), 2)  # #00C0C0 - бирюзовый акцент
        painter.setPen(pen)
        painter.drawRoundedRect(1, 1, self.width()-2, self.height()-2, 12, 12)
        
        # Заголовок
        title_font = QFont("Segoe UI", 28, QFont.Bold)
        painter.setFont(title_font)
        painter.setPen(QColor(255, 255, 255))  # Белый текст
        title_rect = self.rect()
        title_rect.setTop(60)
        title_rect.setHeight(50)
        painter.drawText(title_rect, Qt.AlignCenter, "RoLo Search")
        
        # Версия
        version_font = QFont("Segoe UI", 14)
        painter.setFont(version_font)
        painter.setPen(QColor(0, 192, 192))  # Бирюзовый
        version_rect = self.rect()
        version_rect.setTop(115)
        version_rect.setHeight(30)
        painter.drawText(version_rect, Qt.AlignCenter, "v0.21")
        
        # Статус
        status_font = QFont("Segoe UI", 11)
        painter.setFont(status_font)
        painter.setPen(QColor(204, 204, 204))  # Светло-серый
        status_rect = self.rect()
        status_rect.setTop(170)
        status_rect.setHeight(25)
        painter.drawText(status_rect, Qt.AlignCenter, "Initializing application...")
        
        # Анимированные точки
        dots_rect = self.rect()
        dots_rect.setTop(195)
        dots_rect.setHeight(25)
        
        # Простая анимация точек
        dots_count = int(time.time() * 2) % 4
        dots = "." * dots_count
        painter.drawText(dots_rect, Qt.AlignCenter, dots)
        
    def center_on_screen(self):
        screen = QApplication.desktop().screenGeometry()
        size = self.geometry()
        x = (screen.width() - size.width()) // 2
        y = (screen.height() - size.height()) // 2
        self.move(x, y)

def main():
    app = QApplication(sys.argv)
    
    splash = SplashScreen()
    splash.show()
    
    # Анимация точек
    timer = QTimer()
    timer.timeout.connect(splash.repaint)
    timer.start(500)
    
    app.processEvents()
    
    # Запускаем основное приложение
    exe_dir = os.path.dirname(os.path.abspath(__file__))
    python_exe = os.path.join(exe_dir, "system", "python", "pythonw.exe")
    if not os.path.exists(python_exe):
        python_exe = os.path.join(exe_dir, "system", "python", "python.exe")
    
    main_py = os.path.join(exe_dir, "main.py")
    
    if os.path.exists(python_exe) and os.path.exists(main_py):
        env = os.environ.copy()
        env["PYTHONPATH"] = exe_dir
        env["PYTHONHOME"] = os.path.join(exe_dir, "system", "python")
        env["PYTHONDONTWRITEBYTECODE"] = "1"  # Отключаем __pycache__
        
        # Запускаем main.py
        process = subprocess.Popen([python_exe, main_py], 
                                 cwd=exe_dir, env=env)
        
        # Простое ожидание - достаточно времени для загрузки
        start_time = time.time()
        while time.time() - start_time < 12:  # 12 секунд
            app.processEvents()
            time.sleep(0.1)
            
            # УБРАЛИ проверку process.poll() чтобы всегда ждать 12 секунд
        
        timer.stop()
        splash.close()
        
        # НЕ ждем завершения процесса - просто выходим
        return 0
    else:
        timer.stop()
        splash.close()
        return 1

if __name__ == "__main__":
    sys.exit(main())
